from django.apps import AppConfig


class restaurantConfig(AppConfig):
    name = 'restaurant'
