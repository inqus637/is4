from django.http import HttpResponse
from django.views.generic import TemplateView,ListView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy

from restaurant.models import Restaurant

class restaurantList(ListView):
    model = Restaurant

class restaurantCreate(CreateView):
    model = Restaurant
    fields = ['name', 'calory', 'price']
    success_url = reverse_lazy('restaurant:restaurant_list')

class restaurantUpdate(UpdateView):
    model = Restaurant
    fields = ['name', 'calory', 'price']
    success_url = reverse_lazy('restaurant:restaurant_list')

class restaurantDelete(DeleteView):
    model = Restaurant
    success_url = reverse_lazy('restaurant:restaurant_list')
