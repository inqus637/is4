from django.urls import path

from . import views

app_name = 'restaurants'

urlpatterns = [
  path('', views.restaurantList.as_view(), name='restaurant_list'),
  path('new', views.restaurantCreate.as_view(), name='restaurant_new'),
  path('edit/<int:pk>', views.restaurantUpdate.as_view(), name='restaurant_edit'),
  path('delete/<int:pk>', views.restaurantDelete.as_view(), name='restaurant_delete'),
]
