Для запуска проекта требуется Python3 и менеджер пакетов pip(обычно идет вместе с ним)
1. Открываем в командную строку, переходим в папку с проектом и воспроизводим эти команды.
    pip install -r requirements.txt
    manage.py migrate
    manage.py runserver
2. переходим по ссылке
 <http://localhost:8000/>
